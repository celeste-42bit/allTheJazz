# RPGScript
RPGScipt is a simple method for coding in-terminal text-based rollplay games (RPGs). This is a work in progress and far from finished!
