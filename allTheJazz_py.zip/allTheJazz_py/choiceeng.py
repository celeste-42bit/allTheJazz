from scripts import *
# as redX user "scriptname()"
def mkch2(redA, redB):
    userinput = str(input("ENTER: "))
    while userinput != "A" and userinput != "B" and userinput != "a" and userinput != "b":
        print("Enter either A(a) or B(b)!")
        userinput = str(input("ENTER: "))
    else:
        if userinput == "A" or userinput == "a":
            eval(redA)
        elif userinput == "B" or userinput == "b":
            eval(redB)


def mkch3(redA, redB, redC):
    userinput = str(input("ENTER: "))
    while userinput != "A" and userinput != "B" and userinput != "C" and userinput != "a" and userinput != "b" and userinput != "c":
        print("Enter either A, B or C!")
        userinput = str(input("ENTER: "))
    else:
        if userinput == "A" or userinput == "a":
            eval(redA)
        elif userinput == "B" or userinput == "b":
            eval(redB)
        elif userinput == "C" or userinput == "c":
            eval(redC)


def mkch4(redA, redB, redC, redD):
    userinput = str(input("ENTER: "))
    while userinput != "A" and userinput != "B" and userinput != "C" and userinput != "D" and userinput != "a" and userinput != "b" and userinput != "c" and userinput != "d":
        print("Enter either A, B, C or D!")
        userinput = str(input("ENTER: "))
    else:
        if userinput == "A" or userinput == "a":
            eval(redA)
        elif userinput == "B" or userinput == "b":
            eval(redB)
        elif userinput == "C" or userinput == "c":
            eval(redC)
        elif userinput == "D" or userinput == "d":
            eval(redD)


def mkch5(redA, redB, redC, redD, redE):
    userinput = str(input("ENTER: "))
    while userinput != "A" and userinput != "B" and userinput != "C" and userinput != "D" and userinput != "E" and userinput != "a" and userinput != "b" and userinput != "c" and userinput != "d" and userinput != "e":
        print("Enter either A, B, C, D or E!")
        userinput = str(input("ENTER: "))
    else:
        if userinput == "A" or userinput == "a":
            eval(redA)
        elif userinput == "B" or userinput == "b":
            eval(redB)
        elif userinput == "C" or userinput == "c":
            eval(redC)
        elif userinput == "D" or userinput == "d":
            eval(redD)
        elif userinput == "E" or userinput == "e":
            eval(redE)


def mkch6(redA, redB, redC, redD, redE, redF):
    userinput = str(input("ENTER: "))
    while userinput != "A" and userinput != "B" and userinput != "C" and userinput != "D" and userinput != "E" and userinput != "F" and userinput != "a" and userinput != "b" and userinput != "c" and userinput != "d" and userinput != "e" and userinput != "f":
        print("Enter either A, B, C, D, E or F!")
        userinput = str(input("ENTER: "))
    else:
        if userinput == "A" or userinput == "a":
            eval(redA)
        elif userinput == "B" or userinput == "b":
            eval(redB)
        elif userinput == "C" or userinput == "c":
            eval(redC)
        elif userinput == "D" or userinput == "d":
            eval(redD)
        elif userinput == "E" or userinput == "e":
            eval(redE)
        elif userinput == "F" or userinput == "f":
            eval(redF)


def mkch7(redA, redB, redC, redD, redE, redF, redG):
    userinput = str(input("ENTER: "))
    while userinput != "A" and userinput != "B" and userinput != "C" and userinput != "D" and userinput != "E" and userinput != "F" and userinput != "G" and userinput != "a" and userinput != "b" and userinput != "c" and userinput != "d" and userinput != "e" and userinput != "f" and userinput != "g":
        print("Enter either A, B, C, D, E, F or G!")
        userinput = str(input("ENTER: "))
    else:
        if userinput == "A" or userinput == "a":
            eval(redA)
        elif userinput == "B" or userinput == "b":
            eval(redB)
        elif userinput == "C" or userinput == "c":
            eval(redC)
        elif userinput == "D" or userinput == "d":
            eval(redD)
        elif userinput == "E" or userinput == "e":
            eval(redE)
        elif userinput == "F" or userinput == "f":
            eval(redF)
        elif userinput == "G" or userinput == "g":
            eval(redG)


def mkch8(redA, redB, redC, redD, redE, redF, redG, redH):
    userinput = str(input("ENTER: "))
    while userinput != "A" and userinput != "B" and userinput != "C" and userinput != "D" and userinput != "E" and userinput != "F" and userinput != "G" and userinput != "H" and userinput != "a" and userinput != "b" and userinput != "c" and userinput != "d" and userinput != "e" and userinput != "f" and userinput != "g" and userinput != "h":
        print("Enter either A, B, C, D, E, F, G or H!")
        userinput = str(input("ENTER: "))
    else:
        if userinput == "A" or userinput == "a":
            eval(redA)
        elif userinput == "B" or userinput == "b":
            eval(redB)
        elif userinput == "C" or userinput == "c":
            eval(redC)
        elif userinput == "D" or userinput == "d":
            eval(redD)
        elif userinput == "E" or userinput == "e":
            eval(redE)
        elif userinput == "F" or userinput == "f":
            eval(redF)
        elif userinput == "G" or userinput == "g":
            eval(redG)
        elif userinput == "H" or userinput == "h":
            eval(redH)

