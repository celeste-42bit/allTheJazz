def ch0br0():  # chapter 0 branch 0
    print("I am a script, \nthe script of choice A")


def ch0br1l():  # chapter 0 branch 1 option "left"
    print("I am another script, \nthe script of choice B")


def ch0br1r():  # chapter 0 branch 1 option "right"
    print("I am the third script, \nthe script of choice C")

